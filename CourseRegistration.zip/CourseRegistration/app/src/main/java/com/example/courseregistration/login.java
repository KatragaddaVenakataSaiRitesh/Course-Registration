package com.example.courseregistration;

import androidx.appcompat.app.AppCompatActivity ;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class login extends AppCompatActivity implements View.OnClickListener {
    EditText user, pass;
    Button login;
    int count = 0; //a class level variable to count the number of failed login trial

    static EditText name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        user = findViewById(R.id.usertxt);
        pass = findViewById(R.id.passtxt);
        name = findViewById(R.id.pname);
        login = findViewById(R.id.logtxt);
        login.setOnClickListener(this);
    }
    public void onClick(View view) {
        if (count < 3)
            if (user.getText().toString().equalsIgnoreCase("student1") && pass.getText().toString().equals("123456"))
            {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(getApplicationContext(), "Invalid username or password ", Toast.LENGTH_LONG).show();
                count++;//count the failed login trials
            }
        else{
            //after the fourth failed login
            Toast.makeText(getApplicationContext(), "Access denied", Toast.LENGTH_LONG).show();
            login.setEnabled(false);
        }
    }
}
