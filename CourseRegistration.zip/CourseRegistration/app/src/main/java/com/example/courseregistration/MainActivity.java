package com.example.courseregistration;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    Spinner courseSp;
    TextView feeTv,hoursTV, welcome,feeTotal,hoursTotal;
    Button addBtn, clean;
    CheckBox accCb,medCb;

    String Course[]={"Java","Swift","iOS","Android","Database"};
    String Fee[]={"1300","1500","1350","1400","1000"};
    String Hours[] = {"6","5","5","7","4"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        courseSp=findViewById(R.id.spCourse);
        feeTv=findViewById(R.id.tvFee);
        hoursTV=findViewById(R.id.tvHours);
        addBtn=findViewById(R.id.Btnadd);
        feeTotal=findViewById(R.id.totFee);
        hoursTotal=findViewById(R.id.totHours);
        welcome = findViewById(R.id.weltx);
        welcome.setText("welcome "+ login.name.getText());//use a variable from another activity
        accCb=findViewById(R.id.cbAcc);
        medCb=findViewById(R.id.cbMed);
        clean = findViewById(R.id.clear);

        accCb.setOnCheckedChangeListener(this);
        medCb.setOnCheckedChangeListener(this);
        clean.setOnClickListener(this);
        addBtn.setOnClickListener(this);

        courseSp.setOnItemSelectedListener(this);

        //create array adapter and fill it from the array which created as spinner items
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,Course);
        //set the array adapter as simple spinner
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data to the Spinner
        courseSp.setAdapter(aa);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        feeTv.setText(Fee[i]);
        hoursTV.setText(Hours[i]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onClick(View view) {
        //get the index of the selected item in the spinner
        if(view.getId()==R.id.Btnadd) {
            int i = courseSp.getSelectedItemPosition();
            feeTotal.setText(Fee[i]);
            hoursTotal.setText(Hours[i]);
        }
        else{
            feeTotal.setText("");
            hoursTotal.setText("");
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        String r;
        double res = Double.parseDouble(feeTotal.getText().toString());
        if(compoundButton==accCb)
            if(accCb.isChecked()) {
                res +=1000;
                r = String.format("%.2f", res);
                feeTotal.setText(r);
            }

            else {
                res -= 1000;
                r = String.format("%.2f", res);
                feeTotal.setText(r);
            }

        if(compoundButton==medCb)
            if(medCb.isChecked()) {
                res +=700;
                r = String.format("%.2f", res);
                feeTotal.setText(r);
            }

            else {
                res -= 700;
                r = String.format("%.2f", res);
                feeTotal.setText(r);
            }
    }
}
